
import win32evtlog
import pandas as pd
import tkinter as tk
from tkinter import messagebox
import threading
import time

interval = 3
monitoring = False
suspicious_keywords = ["cmd.exe", "powershell.exe", "regedit.exe", "wmic.exe"]
already_alerted = set()

def read_security_events():
    server = 'localhost'
    logtype = 'Security'
    hand = win32evtlog.OpenEventLog(server, logtype)
    flags = win32evtlog.EVENTLOG_BACKWARDS_READ | win32evtlog.EVENTLOG_SEQUENTIAL_READ
    events = win32evtlog.ReadEventLog(hand, flags, 0)

    event_data = []
    for event in events:
        record = {
            "EventId": event.EventID & 0xFFFF,
            "Source": event.SourceName,
            "TimeGenerated": event.TimeGenerated.Format(),
            "Message": event.StringInserts
        }
        event_data.append(record)
        if len(event_data) >= 50:
            break
    return pd.DataFrame(event_data)

def check_eventlog():
    global monitoring
    last_seen = set()

    while monitoring:
        try:
            df = read_security_events()
            if df.empty:
                print("🔁 無事件資料")
                time.sleep(interval)
                continue

            df_filtered = df[df['EventId'].isin([4720, 4732, 4697, 5379, 4688])]
            new_ids = set(df_filtered['EventId'].astype(str) + df_filtered['TimeGenerated'])
            unseen = new_ids - last_seen
            last_seen.update(unseen)

            if unseen:
                ids = df_filtered[df_filtered['EventId'].astype(str) + df_filtered['TimeGenerated'].isin(unseen)]['EventId'].unique()
                messagebox.showwarning('警報', f'⚠️ 偵測到 EventId: {list(ids)} 的事件！')

            # ✅ 偵測 4688 可疑執行檔（只跳一次）
            df_4688 = df[df['EventId'] == 4688]
            cmd_detected = False
            for row in df_4688.itertuples():
                if row.Message:
                    for msg in row.Message:
                        for keyword in suspicious_keywords:
                            if keyword.lower() in msg.lower():
                                alertkey = f"{keyword.lower()}{row.TimeGenerated}"
                                if alertkey not in already_alerted:
                                    already_alerted.add(alertkey)
                                    messagebox.showwarning('警報', f'⚠️ 偵測到可疑執行檔：{msg}')
                                    cmd_detected = True
                                break
                if cmd_detected:
                    break

            # ✅ 偵測 4720 新增帳戶（每次都跳）
            df_4720 = df[df['EventId'] == 4720]
            for row in df_4720.itertuples():
                account_info = "\n".join(row.Message) if row.Message else "(無詳細資訊)"
                messagebox.showwarning('帳戶建立警報', f'⚠️ 偵測到帳戶新增事件：\n{account_info}')

            if not unseen and not cmd_detected:
                print("✅ 無異常事件（EventLog）")

        except Exception as e:
            print(f"⚠️ 事件讀取錯誤：{str(e)}")

        time.sleep(interval)

def start_monitor():
    global monitoring
    if not monitoring:
        monitoring = True
        threading.Thread(target=check_eventlog, daemon=True).start()
        messagebox.showinfo('啟動', '✅ 已開始監控 EventLog！')

def stop_monitor():
    global monitoring
    monitoring = False
    messagebox.showinfo('停止', '🛑 已停止監控。')

root = tk.Tk()
root.title('EventId 監控小程式（EventLog 版）')
root.geometry('320x200')

start_button = tk.Button(root, text='開始監控', command=start_monitor, height=2, width=20)
start_button.pack(pady=10)

stop_button = tk.Button(root, text='停止監控', command=stop_monitor, height=2, width=20)
stop_button.pack(pady=10)

root.mainloop()
